# import requests
# from pyspark.sql.functions import col
import re
import findspark
findspark.init()
findspark.find()
import os
import pyspark
from pyspark.sql import SparkSession
spark=SparkSession.builder.master("local[1").appName("sparkByExamples.com").getOrCreate()




# companyName = "petrabytes"
# folder_loc = 's3://databricks-training-s3/datasets/core_data/'
# delta_lake_loc = "/mnt/databricks-training-s3/subsurface_lakehouse/"+companyName+'/pb_core_data/'
# database = companyName + '_pb_core_data'
# table = 'core_data_image'


def create_depths(text):

  pattern = '[0-9]{0,}(?=\.)'

  return re.search(pattern, text)[0]

def core_data_processor(folder_loc, delta_lake_loc,database,table):
    # Create image DataFrame using image data source
    image_df = spark.read.format("binaryFile").load(folder_loc)
    df = image_df.toPandas()

    df['depth'] = df['path']
    df['fileName'] = df['path'].apply(os.path.basename)
    df['basinId'] = 'unknown'
    df['basin'] = 'unknown'
    df['wellId'] = 'unknown'
    df['well'] = 'unknown'
    df['wellboreId'] = 'unknown'
    df['wellbore'] = 'unknown'
    df['mapped'] = 'NO'

    df['depth'] = df['path']

    # Create Depth Column

    df['depth'] = df['depth'].apply(create_depths)

    # Sort Values by Depth

    df = df.sort_values(by='depth')

    # Reset the indicies

    df = df.reset_index(drop=True)

    # Use reset_index to add a column into the table for index

    df = df.reset_index(drop=False)

    image_df = spark.createDataFrame(df)
    image_df.write.format('delta').mode("overwrite").option("overwriteSchema", "true").save(delta_lake_loc)
    spark.sql("CREATE DATABASE IF NOT EXISTS {}".format(database))

    # Drop existing Table

    spark.sql("DROP TABLE IF EXISTS {}.{}".format(database, table))

    # Create new Table

    spark.sql("CREATE TABLE {}.{} USING DELTA LOCATION '{}'".format(database, table, delta_lake_loc))

    # return price


