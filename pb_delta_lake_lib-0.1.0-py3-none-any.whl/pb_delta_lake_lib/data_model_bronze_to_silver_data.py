# Copyright © 2021 Petrabytes Corporation. All rights reserved
#=====================================
# Author  : Lalan Ranjan
# @Email  : lranjan@petrabyutes.com
# @Date   : 04-05-22
#=====================================



import re
import findspark
findspark.init()
findspark.find()
import os
import pyspark
from pyspark.sql import SparkSession
spark=SparkSession.builder.master("local[1").appName("sparkByExamples.com").getOrCreate()

def data_processor_bronze_to_silver_data(bronze_database,bronze_table,delta_lake_loc,silver_database,silver_table):
  df=spark.sql(f"select * from {bronze_database}.{bronze_table}")
  # display(image_df)
  # Write to deltalake
  df.write.format('delta').mode("overwrite").option("overwriteSchema", "true").save(delta_lake_loc)
  spark.sql("CREATE DATABASE IF NOT EXISTS {}".format(silver_database))

  # Drop existing Table
  spark.sql("DROP TABLE IF EXISTS {}.{}".format(silver_database, silver_table))

  # Create new Table
  spark.sql("CREATE TABLE {}.{} USING DELTA LOCATION '{}'".format(silver_database, silver_table, delta_lake_loc))




