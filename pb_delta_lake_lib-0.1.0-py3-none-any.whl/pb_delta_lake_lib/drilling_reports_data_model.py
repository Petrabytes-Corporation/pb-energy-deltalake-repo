# import requests
# from pyspark.sql.functions import col
import re
import findspark
findspark.init()
findspark.find()
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql import SparkSession
from pyspark.sql.types import StructField, StructType, StringType, IntegerType, DecimalType, FloatType
from pyspark.sql.functions import lit, col
spark=SparkSession.builder.master("local[1").appName("sparkByExamples.com").getOrCreate()

import lasio
from array import array
import pandas as pd
import uuid
import os
import random



def drilling_reports_data_processor(file_path,file_name, Drilling_Report_filename,delta_lake_loc_header,delta_lake_loc_data,database):
    Drilling_Report_file_ID = random.randint(0, 9999999)
    Output_Header_Table = 'drilling_reports_header'
    Output_Data_Table = file_name + '_' + str(Drilling_Report_file_ID)
    delta_lake_loc_data = delta_lake_loc_data + str(Output_Data_Table)+'/'


    # Creating Drilling Report Header
    drillingHeaderColumns = ['fileId', 'fileName', 'filePath', 'filePathID', 'basinId', 'basinName', 'wellId', 'wellName',
                             'wellboreId', 'wellboreName', 'mapped']
    # curveHeaderColumns = []

    header_pdf = pd.DataFrame(columns=drillingHeaderColumns)
    row_values_dict = {}
    row_values_dict['fileId'] = Drilling_Report_file_ID
    row_values_dict['fileName'] = Drilling_Report_filename
    row_values_dict['filePath'] = file_path
    row_values_dict['filePathID'] = Output_Data_Table
    row_values_dict['basinId'] = "unknown"
    row_values_dict['basinName'] = "unknown"
    row_values_dict['wellId'] = "unknown"
    row_values_dict['wellName'] = "unknown"
    row_values_dict['wellboreId'] = "unknown"
    row_values_dict['wellboreName'] = "unknown"
    row_values_dict['mapped'] = "NO"

    header_pdf = header_pdf.append(row_values_dict, ignore_index=True)
    # display(header_pdf)
    drilling_report_header_frame = spark.createDataFrame(header_pdf)
    # display(drilling_report_header_frame)
    drilling_report_header_frame.write.format('delta').option("overwriteSchema", "true").mode("append").save(delta_lake_loc_header)
    spark.sql("CREATE DATABASE IF NOT EXISTS {}".format(database))
    spark.sql("CREATE TABLE IF NOT EXISTS {}.{} USING DELTA LOCATION '{}'".format(database,Output_Header_Table,delta_lake_loc_header))

    sdf = spark.read.csv(file_path)
    sdf.write.format('delta').mode("overwrite").option("overwriteSchema", "true").save(delta_lake_loc_data)

    try:
      #Create Table from Delta
      spark.sql("CREATE DATABASE IF NOT EXISTS {}".format(database))
      spark.sql("DROP TABLE IF EXISTS {}.{}".format(database, file_name))
      spark.sql("CREATE TABLE {}.{} USING DELTA LOCATION '{}'".format(database, Output_Data_Table, delta_lake_loc_data))
    except Exception as e:
      print('Error with creating SPARK table: ' + str(e))
