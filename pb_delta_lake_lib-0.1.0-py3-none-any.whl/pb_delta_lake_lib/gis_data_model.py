# import requests
# from pyspark.sql.functions import col
import re
import findspark
findspark.init()
findspark.find()
import pyspark
from pyspark.sql import SparkSession
spark=SparkSession.builder.master("local[1").appName("sparkByExamples.com").getOrCreate()

import geopandas as gp
import pandas as pd
import numpy as np
import random
import re
from geopandas import GeoDataFrame
from shapely.geometry import Point



def gis_shp_data_processor(shp_loc,delta_lake_loc_header, delta_lake_loc_data,database):
    gis_file_name = shp_loc[shp_loc.rindex("/") + 1:-4].lower()
    try:
        gis_file_name = gis_file_name[:gis_file_name.index("_us")]
    except:
        gis_file_name=re.sub('[0-9]', '', gis_file_name)

    gis_file_ID = random.randint(0, 9999999)
    Output_Header_Table = 'gis_header'
    Output_Data_Table = gis_file_name + '_' + str(gis_file_ID)
    delta_lake_loc_data = delta_lake_loc_data + str(Output_Data_Table) + '/'
    gisHeaderColumns = ['fileId', 'fileName', 'filePath', 'filePathID', 'basinId', 'basinName', 'wellId', 'wellName',
                        'wellboreId', 'wellboreName', 'mapped']
    # curveHeaderColumns = []

    header_pdf = pd.DataFrame(columns=gisHeaderColumns)
    row_values_dict = {}
    row_values_dict['fileId'] = gis_file_ID
    row_values_dict['fileName'] = gis_file_name
    row_values_dict['filePath'] = shp_loc
    row_values_dict['filePathID'] = Output_Data_Table
    row_values_dict['basinId'] = "unknown"
    row_values_dict['basinName'] = "unknown"
    row_values_dict['wellId'] = "unknown"
    row_values_dict['wellName'] = "unknown"
    row_values_dict['wellboreId'] = "unknown"
    row_values_dict['wellboreName'] = "unknown"
    row_values_dict['mapped'] = "NO"

    header_pdf = header_pdf.append(row_values_dict, ignore_index=True)
    # display(header_pdf)
    gis_header_frame = spark.createDataFrame(header_pdf)
    # display(gis_header_frame)
    gis_header_frame.write.format('delta').option("overwriteSchema", "true").mode("append").save(delta_lake_loc_header)
    spark.sql("CREATE DATABASE IF NOT EXISTS {}".format(database))
    spark.sql("CREATE TABLE IF NOT EXISTS {}.{} USING DELTA LOCATION '{}'".format(database, Output_Header_Table,
                                                                                  delta_lake_loc_header))

    # Create File Name
    # file_name = shp_loc[shp_loc.rindex("/") + 1:-4].lower()
    # Create File path
    filepath = "/dbfs" + shp_loc[5:]
    # print(filepath)
    df = gp.read_file(filepath)
    # display(df)

    # fills in None values with an empty polygon
    df['geometry'] = df['geometry'].fillna()

    # Checking if the data is in Lat/Lng format
    # http://www.lavykim.com/wp1/archives/340
    try:
        if (df.crs != 'epsg:4326'):
            df['geometry'] = df['geometry'].to_crs(4326)
    except Exception as e:
        print(e)

    # turning the 'geometry' column into 'wkt'
    #   val=pd.Series(
    #           map(lambda geom: str(geom.to_wkt()), df['geometry']),
    #           index=df.index, dtype='string')
    df['wkt'] = df['geometry'].to_wkt()

    # drop geometry
    df.drop(['geometry'], axis=1, inplace=True)

    try:
        # Create spark dataframe from df
        dbf_spark = spark.createDataFrame(df)

        # Create delta lake directory
        # delta_path = delta_lake_loc_data + "/" + file_name + "/"
        # dbutils.fs.mkdirs(delta_path)

        # Create parquet from the spark df
        dbf_spark.write.format('delta').mode("overwrite").option("overwriteSchema", "true").save(delta_lake_loc_data)

        # Create sql table from parquet file
        spark.sql("CREATE DATABASE IF NOT EXISTS {}".format(database))
        spark.sql("DROP TABLE IF EXISTS {}.{}".format(database, Output_Data_Table))
        spark.sql("CREATE TABLE {}.{} USING DELTA LOCATION '{}'".format(database, Output_Data_Table, delta_lake_loc_data))
    except Exception as e:
        print('Error with creating SPARK table: ' + str(e))

def gis_csv_data_processor(csv_loc, delta_lake_loc_header,delta_lake_loc_data,database,lat_col,long_col):
    gis_file_name = csv_loc[csv_loc.rindex("/") + 1:-4].lower()
    try:
        gis_file_name = gis_file_name[:gis_file_name.index("_us")]
    except:
        gis_file_name = re.sub('[0-9]', '', gis_file_name)
    gis_file_ID = random.randint(0, 9999999)
    Output_Header_Table = 'gis_header'
    Output_Data_Table = gis_file_name + '_' + str(gis_file_ID)
    delta_lake_loc_data = delta_lake_loc_data + str(Output_Data_Table) + '/'
    gisHeaderColumns = ['fileId', 'fileName', 'filePath', 'filePathID', 'basinId', 'basinName', 'wellId', 'wellName',
                        'wellboreId', 'wellboreName', 'mapped']
    # curveHeaderColumns = []

    header_pdf = pd.DataFrame(columns=gisHeaderColumns)
    row_values_dict = {}
    row_values_dict['fileId'] = gis_file_ID
    row_values_dict['fileName'] = gis_file_name
    row_values_dict['filePath'] = csv_loc
    row_values_dict['filePathID'] = Output_Data_Table
    row_values_dict['basinId'] = "unknown"
    row_values_dict['basinName'] = "unknown"
    row_values_dict['wellId'] = "unknown"
    row_values_dict['wellName'] = "unknown"
    row_values_dict['wellboreId'] = "unknown"
    row_values_dict['wellboreName'] = "unknown"
    row_values_dict['mapped'] = "NO"

    header_pdf = header_pdf.append(row_values_dict, ignore_index=True)
    # display(header_pdf)
    gis_header_frame = spark.createDataFrame(header_pdf)
    # display(gis_header_frame)
    gis_header_frame.write.format('delta').option("overwriteSchema", "true").mode("append").save(delta_lake_loc_header)
    spark.sql("CREATE DATABASE IF NOT EXISTS {}".format(database))
    spark.sql("CREATE TABLE IF NOT EXISTS {}.{} USING DELTA LOCATION '{}'".format(database, Output_Header_Table,
                                                                                  delta_lake_loc_header))

    # Create File Name
    # file_name = csv_loc[csv_loc.rindex("/") + 1:-4].lower()
    # Create File path

    # Read CSV File
    # File should contain Latitude and Longitude columns
    df = pd.read_csv(csv_loc, low_memory=False)

    # Create Geometry Column
    geometry = [Point(xy) for xy in zip(df[long_col], df[lat_col])]

    # Drop Original Lat/Long Columns
    df = df.drop([lat_col, long_col], axis=1)

    # Create GeoDataFrame using Geometry Column
    gdf = GeoDataFrame(df, crs="EPSG:4326", geometry=geometry)

    # Fill in None values with an Empty polygon
    gdf['geometry'] = gdf['geometry'].fillna()

    # Checking if the data is in Lat/Lng format
    # http://www.lavykim.com/wp1/archives/340
    try:
        if (df.crs != 'epsg:4326'):
            gdf['geometry'] = gdf['geometry'].to_crs(4326)
    except Exception as e:
        gdf.set_crs(4326)
        print('No CRS defined: ' + str(e))

    # drop columns that are all None values
    gdf = gdf.mask(gdf.astype(object).eq('None')).dropna(axis=1, how='all')

    # turning the 'geometry' column into 'wkt'
    gdf['wkt'] = gdf['geometry'].to_wkt()

    # drop geometry
    gdf.drop(['geometry'], axis=1, inplace=True)

    try:
        # Create spark dataframe from df
        dbf_spark = spark.createDataFrame(gdf)

        # Create delta lake directory
        # delta_path = delta_lake_loc + "/" + file_name + "/"
        # dbutils.fs.mkdirs(delta_path)

        # Create parquet from the spark df
        dbf_spark.write.format('delta').mode("overwrite").option("overwriteSchema", "true").save(delta_lake_loc_data)

        # Create sql table from parquet file
        spark.sql("CREATE DATABASE IF NOT EXISTS {}".format(database))
        spark.sql("DROP TABLE IF EXISTS {}.{}".format(database, Output_Data_Table))
        spark.sql("CREATE TABLE {}.{} USING DELTA LOCATION '{}'".format(database, Output_Data_Table, delta_lake_loc_data))
    except Exception as e:
        print('Error with creating SPARK table: ' + str(e))
