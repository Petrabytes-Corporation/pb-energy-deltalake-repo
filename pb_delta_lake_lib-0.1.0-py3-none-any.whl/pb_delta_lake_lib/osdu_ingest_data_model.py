import pandas as pd
import requests
import json
import boto3
from botocore.exceptions import ClientError
import os
import uuid
import findspark
findspark.init()
findspark.find()
import pyspark
from pyspark.sql import SparkSession
spark=SparkSession.builder.master("local[1").appName("sparkByExamples.com").getOrCreate()


def OSDU_ingest_data_processor(basin_id, well_id, wellbore_id, traj_file_path, token, companyName):

    # try:
    #     basin_id = getArgument("basin_id")  # eg: '76987'
    #     well_id = getArgument("well_id")  # eg: '63454'
    #     wellbore_id = getArgument("wellbore_id")  # eg: '78467'
    #     # eg: "/dbfs/mnt/databricks-training-s3/datasets/Sample_Data/Trajectories/PB_Trajectory_1.csv"
    #     traj_file_path = getArgument("traj_file_path")
    #     # eg: 'Bearer eyJraWQeyJvcmlnaW5fanRpIjoiOTkxN...'
    #     token = getArgument("Token")
    #     #   well_traj_DE_value=getArgument("traj_val") # eg: 1     (1 for true, o for false)
    #     #   well_log_DE_value=getArgument("well_log_val") # eg: 1     (1 for true, o for false)
    #     companyName = getArgument("company")  # eg: 'petrabytes_prod_'
    # except:
    #     basin_id = "5123543"  # eg: '76987'
    #     well_id = '3168'
    #     wellbore_id = '5277'
    #     traj_file_path = "/dbfs/mnt/databricks-training-s3/datasets/Sample_Data/Trajectories/PB_Trajectory_1.csv"
    #     token = "Bearer eyJraWQiOiJtb29uVGZ5WHFWTEszaVJWZklJTWJSTjBMelpOUUYzNnlQVUZRc25nZ1wvaz0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI2MzEwYWRjNS1lZTNjLTQ0NTktYjQ3Mi1jYjdjYWY1YmYwOTEiLCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV94NzlWdFBlZWoiLCJjbGllbnRfaWQiOiIxYmdmYnEwNmQ4bzIwMGdyaGU2Zm4ya251ciIsIm9yaWdpbl9qdGkiOiIzMTY2MzBkNC0zNTE3LTQzMjMtYTg3Zi0wYTdmODgyYzg3MzUiLCJldmVudF9pZCI6ImQzYTJhZTBmLTYxYjktNDU2NS1iYmEyLWZmYTA5M2VkNjUzMyIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiYXdzLmNvZ25pdG8uc2lnbmluLnVzZXIuYWRtaW4iLCJhdXRoX3RpbWUiOjE2NTQ1MDcwNDAsImV4cCI6MTY1NDUxMDYzOSwiaWF0IjoxNjU0NTA3MDQwLCJqdGkiOiIxMzY5MTYxZC1mNTE5LTQxOTYtODdmNy05YjlhYjJmODg2M2IiLCJ1c2VybmFtZSI6InNhc2hpZ3VudHVydUBwZXRyYWJ5dGVzLmNvbSJ9.sFC_w68eyCLyXcZjiyLEjli1BMOkXiYJDT0X4L60XMOrZRDDlnpkarH4ZtYu1YdGuxlwfNdOHtzmbbbf80fcfCkGit380qHlBWdItNEd8hgDhIvQ508axBR1AZli3Kjgujwl-5GF1RcaLdO86FmTGr7dvint1NNbSE9GTNeO2umZvClj1vXQn6T2vo5Bojc0nRbgpcLcbEby9j3xKQuhSKmf7MpJx3mWKQNxjuydcXZBAmtyadwm3yrUkEhKhIb_ZEoSlILsTobMwVKMEE-lSEgiK0iQrkmLzCkmUs1XykYFb2m0Lc_FwIOccvpN7IL9BfPM75nZuzpuY9ZUj1JN0w"  # eg: 'Bearer eyJraWQeyJvcmlnaW5fanRpIjoiOTkxN...'
    #     well_traj_DE_value = 0  # eg: 1     (1 for true, o for false)
    #     well_log_DE_value = 0  # eg: 1     (1 for true, o for false)

    # companyName = "petrabytes_"  # eg: 'petrabytes_prod_'
    db_name = companyName + "bronze_well_registry_db"


    def getWellSchemaData(basin_id, well_id, well_name, company, latitude, longitude, country, spud_date):
        well_schema = {
            #     Below is the data based on well schema
            "data": {
                #       "FacilityStates": [
                #         {
                #           "FacilityStateTypeID": "osdu:reference-data--FacilityStateType:Suspended:"
                #         }
                #       ],
                "ResourceLifecycleStatus": None,
                "DefaultVerticalMeasurementID": "RotaryTable",
                "SpatialLocation.Wgs84Coordinates": {
                    "geometries": [
                        {
                            "coordinates": [
                                latitude,
                                longitude
                            ],
                            "type": "point"
                        }
                    ],
                    "type": "geometrycollection"
                },
                "ResourceCurationStatus": None,
                "TechnicalAssuranceID": None,
                "Source": "TNO",
                "FacilityName": well_name,
                "FacilityID": well_id,
                "VerticalMeasurements": [
                    {
                        "WellboreTVDTrajectoryID": None,
                        "VerticalCRSID": None,
                        "VerticalMeasurementSourceID": None,
                        "VerticalReferenceID": None,
                        "VerticalMeasurementID": None,
                        "VerticalMeasurementPathID": None,
                        "VerticalMeasurement": None,
                        "VerticalMeasurementTypeID": None,
                        "VerticalMeasurementDescription": None,
                        "VerticalMeasurementUnitOfMeasureID": None
                    }
                ],
                "VersionCreationReason": None,
                "ResourceSecurityClassification": None,
                "InterestTypeID": None,
                "DataSourceOrganisationID": None,
                "SpatialLocation.SpatialParameterTypeID": None,
                "ExistenceKind": None,
                "SpatialLocation.CoordinateQualityCheckPerformedBy": None,
                "FacilityOperators": [
                    {
                        "FacilityOperatorID": None,
                        "FacilityOperatorOrganisationID": f"osdu:master-data--Organisation:{company}:"
                    }
                ],
                "FacilityTypeID": "osdu:reference-data--FacilityType:Well:",
                "NameAliases": [
                    {
                        "AliasName": well_name,
                        "AliasNameTypeID": "osdu:reference-data--AliasNameType:Well:",
                        "DefinitionOrganisationID": None
                    },
                    {
                        "AliasName": well_name,
                        "AliasNameTypeID": "osdu:reference-data--AliasNameType:UWI:",
                        "DefinitionOrganisationID": None
                    }
                ],
                "DefaultVerticalCRSID": None,
                "FacilityEvents": [
                    {
                        "EffectiveDateTime": spud_date,
                        "FacilityEventTypeID": "osdu:reference-data--FacilityEventType:Spud:"
                    }
                ],
                "GeoContexts": [
                    {
                        "BasinID": basin_id,
                        "FieldID": None,
                        "PlayID": None,
                        "GeoPoliticalEntityID": f"osdu:master-data--GeoPoliticalEntity:{country}:",
                        "GeoTypeID": "osdu:reference-data--GeoPoliticalEntityType:Country:",
                        "ProspectID": None
                    }
                ],
                "CurrentOperatorID": None,
                "SpatialLocation.QualitativeSpatialAccuracyTypeID": None,
                "SpatialLocation.SpatialGeometryTypeID": None,
                "OperatingEnvironmentID": "osdu:reference-data--OperatingEnvironment:Off:",
                "ResourceHomeRegionID": None,
                "InitialOperatorID": None,
                "SpatialLocation.QuantitativeAccuracyBandID": None
            },

            #     Below is the ID for the current entry
            "id": f"osdu:master-data--Well:{well_id}",

            #     Below is the kind of the schema to be added
            "kind": "osdu:wks:master-data--Well:1.0.0",
            "acl": {
                "viewers": [
                    "data.default.viewers@osdu.example.com"
                ],
                "owners": [
                    "data.default.owners@osdu.example.com"
                ]
            },
            "legal": {
                "legaltags": [
                    "osdu-public-usa-dataset"
                ],
                "otherRelevantDataCountries": [
                    "US"
                ]
            }
        }
        return well_schema


    def getWellboreSchemaData(basin_id, well_id, wb_name, wb_id, trajectory_type):
        wellbore_schema = {
            "data": {
                #                 "FacilityStates": [
                #                     {
                #                         "FacilityStateTypeID": "osdu:reference-data--FacilityStateType:Abandoned:"
                #                     }
                #                 ],
                "GeographicBottomHoleLocation.SpatialParameterTypeID": None,
                "GeographicBottomHoleLocation.CoordinateQualityCheckPerformedBy": None,
                "ResourceLifecycleStatus": None,
                "TargetFormation": None,
                "DefaultVerticalMeasurementID": None,
                "ResourceCurationStatus": None,
                "TechnicalAssuranceID": None,
                "FacilityName": wb_name,
                "Source": None,
                "DefinitiveTrajectoryID": None,
                "FacilityID": None,
                "GeographicBottomHoleLocation.QualitativeSpatialAccuracyTypeID": None,
                "DrillingReasons": [
                    {
                        "DrillingReasonTypeID": "osdu:reference-data--DrillingReasonType:EXP-HC:"
                    }
                ],
                "VerticalMeasurements": [
                    {
                        "WellboreTVDTrajectoryID": None,
                        "VerticalCRSID": None,
                        "VerticalMeasurementSourceID": None,
                        "VerticalReferenceID": "Measured_From",
                        "VerticalMeasurementID": "TD-Original",
                        "VerticalMeasurementPathID": "osdu:reference-data--VerticalMeasurementPath:MD:",
                        "VerticalMeasurement": None,
                        "VerticalMeasurementTypeID": "osdu:reference-data--VerticalMeasurementType:TD:",
                        "VerticalMeasurementDescription": None,
                        "VerticalMeasurementUnitOfMeasureID": None
                    }
                ],
                "VersionCreationReason": None,
                "ResourceSecurityClassification": None,
                "SequenceNumber": 1,
                "DataSourceOrganisationID": None,
                "KickOffWellbore": None,
                "SpatialLocation.SpatialParameterTypeID": None,
                "ExistenceKind": None,
                "SpatialLocation.CoordinateQualityCheckPerformedBy": None,
                "FacilityTypeID": "osdu:reference-data--FacilityType:Wellbore:",
                "NameAliases": [
                    {
                        "AliasName": wb_name,
                        "AliasNameTypeID": "osdu:reference-data--AliasNameType:UWI:",
                        "DefinitionOrganisationID": None
                    }
                ],
                "ProjectedBottomHoleLocation.CoordinateQualityCheckPerformedBy": None,
                "FacilityEvents": [
                    {
                        "EffectiveDateTime": "2003-05-02T00:00:00+0000",
                        "FacilityEventTypeID": "osdu:reference-data--FacilityEventType:TDReached:"
                    }
                ],
                "ProjectedBottomHoleLocation.QuantitativeAccuracyBandID": None,
                "GeoContexts": [
                    {
                        "BasinID": basin_id,
                        "FieldID": None,
                        "PlayID": None,
                        "GeoPoliticalEntityID": None,
                        "GeoTypeID": None,
                        "ProspectID": None
                    }
                ],
                "ProjectedBottomHoleLocation.SpatialParameterTypeID": None,
                "CurrentOperatorID": "osdu:master-data--Organisation:Neptune%20Energy%20Netherlands%20B.V.:",
                "SpatialLocation.QualitativeSpatialAccuracyTypeID": None,
                "ProjectedBottomHoleLocation.SpatialGeometryTypeID": None,
                "SpatialLocation.SpatialGeometryTypeID": None,
                "OperatingEnvironmentID": "osdu:reference-data--OperatingEnvironment:Off:",
                "ProjectedBottomHoleLocation.QualitativeSpatialAccuracyTypeID": None,
                "ResourceHomeRegionID": None,
                "GeographicBottomHoleLocation.QuantitativeAccuracyBandID": None,
                "PrimaryMaterialID": "osdu:reference-data--MaterialType:Oil:",
                "InitialOperatorID": "osdu:master-data--Organisation:Gaz%20de%20France:",
                "GeographicBottomHoleLocation.SpatialGeometryTypeID": None,
                "WellID": f"osdu:master-data--Well:{well_id}:",
                "SpatialLocation.QuantitativeAccuracyBandID": None,
                "TrajectoryTypeID": f"osdu:reference-data--WellboreTrajectoryType:{trajectory_type}:"
            },
            "id": f"osdu:master-data--Wellbore:{wb_id}",
            "kind": "osdu:wks:master-data--Wellbore:1.0.0",
            "acl": {
                "viewers": [
                    "data.default.viewers@osdu.example.com"
                ],
                "owners": [
                    "data.default.owners@osdu.example.com"
                ]
            },
            "legal": {
                "legaltags": [
                    "osdu-public-usa-dataset"
                ],
                "otherRelevantDataCountries": [
                    "US"
                ]
            }
        }
        return wellbore_schema


    def addDataToOSDU(payload, token):
        headers = {
            'Content-Type': 'application/json',
            'data-partition-id': 'osdu',
            'Authorization': token
        }

        url = "https://petrabytes.accelerator.paas.47lining.com/api/storage/v2/records"
        response = requests.request("PUT", url, headers=headers, data=payload)
        return response.text


    def getDatasetStorageInstructions(token):
        payload = {}
        headers = {
            'Content-Type': 'application/json',
            'data-partition-id': 'osdu',
            'Authorization': token
        }
        url = "https://petrabytes.accelerator.paas.47lining.com/api/dataset/v1/getStorageInstructions/?kindSubType=dataset--File.Generic"
        response = requests.request(
            "GET", url, headers=headers, data=payload).json()
        return response


    def upload_file(file_name, bucket, service_name, region_name, aws_access_key_id, aws_secret_access_key, aws_session_token, object_name=None):
        """Upload a file to an S3 bucket

        :param file_name: File to upload
        :param bucket: Bucket to upload to
        :param object_name: S3 object name. If not specified then file_name is used
        :return: True if file was uploaded, else False
        """

        # If S3 object_name was not specified, use file_name
        if object_name is None:
            object_name = os.path.basename(file_name)

        # Upload the file
        s3_client = boto3.client(service_name=service_name,
                                region_name=region_name,
                                aws_access_key_id=aws_access_key_id,
                                aws_secret_access_key=aws_secret_access_key,
                                aws_session_token=aws_session_token)
        try:
            response = s3_client.upload_file(file_name, bucket, object_name)
            print(response)
        except ClientError as e:
            return False
        return True


    def getDatasetRegisterSchema(s3_file_path):
        dataset_schema = {
            "datasetRegistries": [
                {
                    "kind": "osdu:wks:dataset--File.Generic:1.0.0",
                    "acl": {
                        "viewers": [
                            "data.default.viewers@osdu.example.com"
                        ],
                        "owners": [
                            "data.default.owners@osdu.example.com"
                        ]
                    },
                    "legal": {
                        "legaltags": [
                            "osdu-public-usa-dataset"
                        ],
                        "otherRelevantDataCountries": [
                            "US"
                        ],
                        "status": "compliant"
                    },
                    "data": {
                        "DatasetProperties": {
                            "FileSourceInfo": {
                                "FileSource": "",
                                "PreLoadFilePath": s3_file_path
                            }
                        },
                        "ResourceSecurityClassification": "osdu:reference-data--ResourceSecurityClassification:RESTRICTED:",
                        "SchemaFormatTypeID": "osdu:reference-data--SchemaFormatType:TabSeparatedColumnarText:"
                    },
                    "meta": [],
                    "tags": {}
                }
            ]
        }
        return dataset_schema


    def getWBTrajectorySchema(file_name, wellbore_id, dataset_id, wb_trajectory_id):
        wb_trajectory_schema = [
            {
                "data": {
                    "Description": "Wellbore Trajectory",
                    "Name": file_name,
                    "Datasets": [
                        dataset_id
                    ],
                    "ResourceSecurityClassification": "osdu:reference-data--ResourceSecurityClassification:RESTRICTED:",
                    "WellboreID": f"osdu:master-data--Wellbore:{wellbore_id}",
                    "TopDepthMeasuredDepth": 25,
                    "BaseDepthMeasuredDepth": 4500.01,
                },
                "id": f"osdu:work-product-component--WellboreTrajectory:{wb_trajectory_id}",
                "kind": "osdu:wks:work-product-component--WellboreTrajectory:1.0.0",
                "acl": {
                    "viewers": [
                        "data.default.viewers@osdu.example.com"
                    ],
                    "owners": [
                        "data.default.owners@osdu.example.com"
                    ]
                },
                "legal": {
                    "legaltags": [
                        "osdu-public-usa-dataset"
                    ],
                    "otherRelevantDataCountries": [
                        "US"
                    ]
                }
            }
        ]
        return wb_trajectory_schema


    def registerDataset(payload, token):
        headers = {
            'Content-Type': 'application/json',
            'data-partition-id': 'osdu',
            'Authorization': token
        }
        url = "https://petrabytes.accelerator.paas.47lining.com/api/dataset/v1/registerDataset"
        response = requests.request("PUT", url, headers=headers, data=payload)
        return response.json()["datasetRegistries"][0]["id"]

    delta_well = spark.sql(f"select * from {db_name}.wells where basinId = {basin_id} and wellId = {well_id}").toPandas().iloc[0]
    well_id = str(delta_well["wellId"])
    well_name = str(delta_well["wellName"])
    basin_id = str(delta_well["basinId"])
    latitude = delta_well["latitude"]
    longitude = delta_well["longitude"]
    company = str(delta_well["company"])
    country = str(delta_well["country"])
    spud_date = str(delta_well["spudDate"])
    well_data_schema = json.dumps([getWellSchemaData(basin_id, well_id, well_name, company, latitude, longitude, country, spud_date)])
    response = addDataToOSDU(well_data_schema, token)
    print(response)

    delta_wellbore = spark.sql(f"select * from {db_name}.wellbore where basinId = {basin_id} and wellId = {well_id} and wellboreId = {wellbore_id}").toPandas().iloc[0]
    wb_id = str(delta_wellbore["wellboreId"])
    wb_name = str(delta_wellbore["wellboreName"])
    basin_id = str(delta_wellbore["basinId"])
    well_id = str(delta_wellbore["wellId"])
    trajectory_type = ""
    wellbore_data_schema = json.dumps([getWellboreSchemaData(basin_id, well_id, wb_name, wb_id, trajectory_type)])
    response = addDataToOSDU(wellbore_data_schema, token)
    print(response)

    response = getDatasetStorageInstructions(token)

    service_name = "s3"
    region_name = response["storageLocation"]["region"]
    aws_access_key_id = response["storageLocation"]["credentials"]["accessKeyId"]
    aws_secret_access_key = response["storageLocation"]["credentials"]["secretAccessKey"]
    aws_session_token = response["storageLocation"]["credentials"]["sessionToken"]
    file_name = traj_file_path
    bucket = response["storageLocation"]["unsignedUrl"].split("/")[2]
    object_name = "/".join(response["storageLocation"]["unsignedUrl"].split("/")[3:]) + traj_file_path.split("/")[-1]
    isUploaded = upload_file(file_name, bucket, service_name, region_name, aws_access_key_id, aws_secret_access_key, aws_session_token, object_name)
    if isUploaded:
        print("File Uploaded Successfully")
        s3_upload_file_path = response["storageLocation"]["unsignedUrl"]+traj_file_path.split("/")[-1]
        datasetRegisterSchema = json.dumps(getDatasetRegisterSchema(s3_upload_file_path))
        dataset_id = registerDataset(datasetRegisterSchema, token)
        wb_trajectory_id = uuid.uuid4().hex
        file_name = traj_file_path.split("/")[-1]
        WBTrajectorySchema = json.dumps(getWBTrajectorySchema(file_name, wellbore_id, dataset_id, wb_trajectory_id))
        response = addDataToOSDU(WBTrajectorySchema, token)
        print(response)