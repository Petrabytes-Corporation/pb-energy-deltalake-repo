# Databricks notebook source
# Databricks notebook source
import random
import json
import requests
import lasio
import pandas as pd
import math
import numpy as np
import findspark
findspark.init()
findspark.find()
import pyspark
from pyspark.sql import SparkSession
spark=SparkSession.builder.master("local[1").appName("sparkByExamples.com").getOrCreate()


def OSDU_query_data_processor(wells_list, Token, companyName, basinID, basinName, well_traj_DE_value, well_log_DE_value,
                           well_formation_DE_value, Delta_Data_Path):
    well_list = wells_list.split(",")
    # well_list=[]
    # n=4
    # for index in range(0, len(wells_list), n):
    #     well_list.append(wells_list[index : index + n])

    # #print(well_list)

    headers = {
        "Authorization": str(Token),
        "Content-Type": "application/json",
        "data-partition-id": "osdu"
    }

    def queryWells(headers):
        json = {
            "kind": "osdu:wks:master-data--Well:1.0.0",
            "query": "data:*",
            "offset": 0,
            "limit": 1000,
        }
        response = requests.post("https://petrabytes.accelerator.paas.47lining.com/api/search/v2/query_with_cursor",
                                 json=json, headers=headers)
        dict_data = response.json()
        total_count = dict_data["totalCount"]
        well_result = dict_data["results"]

        wells_dict = {}
        iter_count = 0
        while iter_count < math.ceil(total_count / 1000):
            if iter_count != 0:
                json["cursor"] = dict_data["cursor"]
                response = requests.post("https://petrabytes.accelerator.paas.47lining.com/api/search/v2/query_with_cursor",
                                         json=json, headers=headers)
                dict_data = response.json()
                well_result = dict_data["results"]

            for well in well_result:
                well_dict = {}
                wellId = well["id"].split(":")[-1]
                data = well["data"]
                try:
                    Latitude = data["SpatialLocation.Wgs84Coordinates"]["geometries"][0]["coordinates"][0]
                except:
                    Latitude = ""
                well_dict["latitude"] = Latitude
                try:
                    Longitude = data["SpatialLocation.Wgs84Coordinates"]["geometries"][0]["coordinates"][1]
                except:
                    Longitude=""
                well_dict["longitude"] = Longitude
                WellName = data["FacilityName"]
                well_dict["wellName"] = WellName
                wells_dict[wellId] = well_dict
            iter_count = iter_count + 1
        return wells_dict

    def queryWellbores(headers, wellId):
        json = {
            "kind": "osdu:*:master-data--Wellbore:*",
            "query": "data.WellID:" + wellId,
            "offset": 0,
            "limit": 10000,
            "returnedFields": ["id"]
        }
        response = requests.post("https://petrabytes.accelerator.paas.47lining.com/api/search/v2/query", json=json,
                                 headers=headers)
        dict_data = response.json()
        wellbore_result = dict_data["results"]
        wellbores_list = []
        for wellbore in wellbore_result:
            wellboreId = wellbore["id"].split(":")[-1]
            wellbores_list.append(wellboreId)
        return wellbores_list

    def queryWellboreTrajectory(headers, wellboreId):
        json = {
            "kind": "osdu:*:work-product-component--WellboreTrajectory:*",
            "query": "data.WellboreID:" + wellboreId,
            "offset": 0,
            "limit": 10000
        }
        response = requests.post("https://petrabytes.accelerator.paas.47lining.com/api/search/v2/query", json=json,
                                 headers=headers)
        dict_data = response.json()
        wellboreTraj_result = dict_data["results"]
        wellboreTraj_list = []
        for wellboreTrajectory in wellboreTraj_result:
            wellboreTraj_Name = wellboreTrajectory["data"]["Name"]
            datasets = wellboreTrajectory["data"]["Datasets"]
            topMD = wellboreTrajectory["data"]["TopDepthMeasuredDepth"]
            bottomMD = wellboreTrajectory["data"]["BaseDepthMeasuredDepth"]
            wellboreTraj_list.append(
                {"wellboreTraj_Name": wellboreTraj_Name, "datasets": datasets, "topMD": topMD, "bottomMD": bottomMD})
        return wellboreTraj_list

    def queryWellboreLogs(headers, wellboreId):
        json = {
            "kind": "osdu:*:work-product-component--WellLog:*",
            "query": "data.WellboreID:" + wellboreId,
            "offset": 0,
            "limit": 10000
        }
        response = requests.post("https://petrabytes.accelerator.paas.47lining.com/api/search/v2/query", json=json,
                                 headers=headers)
        dict_data = response.json()
        wellboreLogs_result = dict_data["results"]
        wellboreLogs_list = []
        wellboreDatasets = []
        for wellboreLog in wellboreLogs_result:
            wellboreLog_Name = wellboreLog["data"]["Name"]
            datasets = wellboreLog["data"]["Datasets"]
            if datasets not in wellboreDatasets:
                wellboreDatasets.append(datasets)
                wellboreLogs_list.append({"wellboreLog_Name": wellboreLog_Name, "datasets": datasets})
        return wellboreLogs_list

    def queryWellboreTrajectoryData(headers, datasetIDs):
        json = {
            "datasetRegistryIds": [datasetIDs]
        }
        response = requests.post("https://petrabytes.accelerator.paas.47lining.com/api/dataset/v1/getRetrievalInstructions",
                                 json=json, headers=headers)
        dict_data = response.json()
        file_url = dict_data["delivery"][0]["retrievalProperties"]["signedUrl"]
        data_response = requests.get(file_url)
        wellboreTrajData_result = data_response.text
        return wellboreTrajData_result

    def queryWellboreLogData(headers, datasetIDs):
        json = {
            "datasetRegistryIds": [datasetIDs]
        }
        response = requests.post("https://petrabytes.accelerator.paas.47lining.com/api/dataset/v1/getRetrievalInstructions",
                                 json=json, headers=headers)
        dict_data = response.json()
        file_url = dict_data["delivery"][0]["retrievalProperties"]["signedUrl"]
        data_response = requests.get(file_url)
        wellboreLogData_result = data_response.text
        return wellboreLogData_result

    curveHeaderColumns = ['wellId', 'wellName', 'location', 'apiNumber', 'airGap', 'airGapUnit', 'company',
                          'waterDepth', 'waterDepthUnit', 'basinId', 'basinName', 'country', 'glElevation',
                          'glElevationUnit', 'countryArea', 'waterDensity', 'waterDensityUnit', 'stateProvinence',
                          'timeZone', 'latitude', 'longitude', 'desc']

    header_pdf = pd.DataFrame(columns=curveHeaderColumns)
    curvesCount = len(well_list)
    # print(curvesCount)

    for k in range(0, curvesCount):
        wellId = well_list[k]
        wellName = str(well_list[k])
        location = "Offshore"
        apiNumber = str(123)
        airGap = str(0)
        airGapUnit = "m"
        company = ""
        waterDepth = str(0)
        waterDepthUnit = "m"
        basinId = basinID
        basinName = basinName
        country = "United states"
        glElevation = str(0)
        glElevationUnit = "m"
        countryArea = "CA"
        waterDensity = str(1000)
        waterDensityUnit = "kg/m3"
        stateProvinence = "CA"
        timeZone = "-06:00 : America/Chicago"
        latitude = str(0)
        longitude = str(0)
        desc = "None"

    input_data = spark.sql("select wellId from {}_well_registry_db.wells".format(companyName)).collect()
    # print(input_data)
    input_data_list = []
    for input in input_data:
        input_data_list.append(input.asDict()['wellId'])
    # print(basinName)

    well_dict = queryWells(headers)

    for item in well_list:
        #         print(well_dict)
        well_det = well_dict[str(item)]
        wellName = well_det["wellName"]
        latitude = well_det["latitude"]
        longitude = well_det["longitude"]
        if int(item) in input_data_list:
            spark.sql(
                f"UPDATE {companyName}_well_registry_db.wells SET airGap={airGap},apiNumber='{apiNumber}',company='{company}',country='{country}',glElevation={glElevation},glElevationUnit='{glElevationUnit}',location='{location}',basinName='{basinName}',waterDensity={waterDensity},waterDensityUnit='{waterDensityUnit}',waterDepth={waterDepth},waterDepthUnit='{waterDepthUnit}',stateProvinence='{stateProvinence}',wellId={item},wellName='{wellName}',basinId={basinId},timeZone='{timeZone}',latitude={latitude},longitude={longitude},desc='{desc}',countryArea='{countryArea}',airGapUnit='{airGapUnit}' where wellId='{item}'")
            # print("update")
        else:
            spark.sql(
                f"INSERT INTO {companyName}_well_registry_db.wells (airGap,apiNumber,company,country,glElevation,glElevationUnit,location,basinId,basinName,waterDensity,waterDensityUnit,waterDepth,waterDepthUnit,wellId,wellName,stateProvinence,timeZone,latitude,longitude,desc,countryArea,airGapUnit,version,rrcNumber,companyNumber,county,fieldName,slant,spudDate,state,status,wellNumber,wellType) VALUES({airGap},'{apiNumber}', '{company}','{country}',{glElevation}, '{glElevationUnit}','{location}',{basinId},'{basinName}',{waterDensity},'{waterDensityUnit}',{waterDepth},'{waterDepthUnit}',{item},'{wellName}','{stateProvinence}','{timeZone}',{latitude},{longitude},'{desc}','{countryArea}','{airGapUnit}',null,null,null,null,null,null,null,null,null,null,null)")
            # print("insert")

    wellbores_list = []
    for item in well_list:
        wellbore = queryWellbores(headers, str(item))
        wellbores_list.append(wellbore)
    # print(wellbores_list)

    curveHeaderColumns = ['basinId', 'basinName', 'wellId', 'wellName', 'wellboreId', 'wellboreName', 'desc']
    # curveHeaderColumns = []
    header_pdf = pd.DataFrame(columns=curveHeaderColumns)
    curvesCount = len(wellbores_list)

    row_values_dict = {}
    # print(curvesCount)
    wellnames = {}
    for k in range(0, len(well_list)):
        wellbores = []
        for j in range(0, len(wellbores_list[k])):
            wellboreId = wellbores_list[k][j]
            wellbores.append(wellboreId)
            wellnames[well_list[k]] = wellbores
        finalwellbores = []
    for key, value in wellnames.items():
        basinId = basinID
        basinName = basinName
        wellId = key
        wellName = well_dict[str(key)]["wellName"]
        # print(wellName)
        wellboreId = value
        wellboreName = str(value) + "_wellbore"
        finalwellbores.append(wellboreId)
    # print(finalwellbores)

    input_data = spark.sql("select wellboreId from {}_well_registry_db.wellbore".format(companyName)).collect()
    # #print(input_data)
    input_data_list = []
    for input in input_data:
        input_data_list.append(input.asDict()['wellboreId'])
    # print(basinName)
    for key, j in wellnames.items():
        for value in j:
            value = int(value)
            if value in input_data_list:
                # print(
                #     f"update {companyName}_well_registry_db.wellbore set wellboreName='{str(value)}_Wellbore', wellName = '{well_dict[str(key)]['wellName']}' where wellboreId = {str(value)} and wellId = {str(key)}")
                header = spark.sql(
                    f"update {companyName}_well_registry_db.wellbore set wellboreName='{str(value)}_Wellbore', wellName = '{well_dict[str(key)]['wellName']}' where wellboreId = {str(value)} and wellId = {str(key)}")
                # print(f"update {companyName}_well_registry_db.wellbore set wellboreName='{str(value)}_Wellbore' where wellboreId = {str(value)} and wellId = {str(key)} and wellName = '{str(key)}_well'")
            else:
                # print(
                #     f"insert into {companyName}_well_registry_db.wellbore values('{basinId}','{basinName}','{key}','{well_dict[str(key)]['wellName']}','{value}','{value}_wellbore','{desc}')")
                header_data = spark.sql(
                    f"insert into {companyName}_well_registry_db.wellbore values('{basinId}','{basinName}','{key}','{well_dict[str(key)]['wellName']}','{value}','{value}_wellbore','{desc}')")
                # print("insert into " + companyName + "_well_registry_db.wellbore values('"+str(basinId)+"','"+str(basinName)+"','"+str(key)+"','"+str(key)+"_well"+"','"+str(value)+"','"+str(value)+"_wellbore"+"','"+str(desc)+"')")

    wellboretrajectory_list = []
    for i in (finalwellbores):
        for item in i:
            wellboretrajectory = queryWellboreTrajectory(headers, item)
            wellboretrajectory_list.append(wellboretrajectory)
    # print(wellboretrajectory_list)

    # COMMAND ----------

    for i in (wellboretrajectory_list):
        for item in i:
            wellboreId = item['wellboreTraj_Name'][0:4]
            # print(wellboreId)

    # COMMAND ----------

    wellborelogs_list = {}
    for i in (finalwellbores):
        for item in i:
            welllogsdata = queryWellboreLogs(headers, item)
            wellborelogs_list[item] = welllogsdata
    # print(wellborelogs_list)

    # COMMAND ----------

    wellboretrajectorydata_list = []
    for i in (wellboretrajectory_list):
        for item in i:
            datasets = item['datasets'][0]
            wellboreTraj_Data = queryWellboreTrajectoryData(headers, datasets)
            wellboretrajectorydata_list.append(wellboreTraj_Data)

    # print(wellboretrajectorydata_list)

    # COMMAND ----------

    def get_tvd(md1, incl1, azm1, md2, incl2, azm2):
        MD = md2 - md1
        azm1 = math.radians(azm1)
        azm2 = math.radians(azm2)
        incl1 = math.radians(incl1)
        incl2 = math.radians(incl2)
        B_rad = math.acos(math.cos(incl2 - incl1) - (math.sin(incl1) * math.sin(incl2) * (1 - math.cos(azm2 - azm1))))
        B_deg = math.degrees(B_rad)
        try:
            RF = (2 / B_rad) * math.tan(math.radians(B_deg / 2))
        except:
            RF = 1

        North = (MD / 2) * (math.sin(incl1) * math.cos(azm1) + math.sin(incl2) * math.cos(azm2)) * RF
        East = (MD / 2) * (math.sin(incl1) * math.sin(azm1) + math.sin(incl2) * math.sin(azm2)) * RF
        TVD = (MD / 2) * (math.cos(incl1) + math.cos(incl2)) * RF

        return [MD, TVD, North, East]

    # COMMAND ----------

    def md_tvd(data_val):
        tvd_arr = np.zeros(len(data_val))
        North_arr = np.zeros(len(data_val))
        East_arr = np.zeros(len(data_val))
        data_val = np.insert(data_val, 3, tvd_arr, axis=1)
        data_val = np.insert(data_val, 4, North_arr, axis=1)
        data_val = np.insert(data_val, 5, East_arr, axis=1)
        for i in range(len(data_val)):
            if i == len(data_val) - 1: break
            md1 = data_val[i][0]
            incl1 = data_val[i][1]
            azm1 = data_val[i][2]

            md2 = data_val[i + 1][0]
            incl2 = data_val[i + 1][1]
            azm2 = data_val[i + 1][2]

            tvd1 = data_val[i][3]
            North1 = data_val[i][4]
            East1 = data_val[i][5]

            tvd2 = data_val[i - 1][3]
            North2 = data_val[i - 1][4]
            East2 = data_val[i - 1][5]

            TVD_Data = get_tvd(md1, incl1, azm1, md2, incl2, azm2)

            md2 = md1 + TVD_Data[0]
            tvd2 = tvd2 + TVD_Data[1]
            North2 = North2 + TVD_Data[2]
            East2 = East2 + TVD_Data[3]
            if np.isnan(md1) or np.isnan(tvd1) or np.isnan(incl2): continue
            data_val[i] = [md2, incl2, azm2, tvd2, North2, East2]
        data_val = data_val[:-2]

        return (data_val)

    # COMMAND ----------

    # datasets=wellboretrajectory[0]['datasets'][0]
    # log_csv= queryWellboreLogData(headers, datasets)
    deviationdata = {}
    for i in (wellboretrajectory_list):
        for item in i:
            wellboreId = item['wellboreTraj_Name'][0:4]
            datasets = item['datasets'][0]
            log_csv = queryWellboreTrajectoryData(headers, datasets)
            log_Df = pd.DataFrame([log_csv.split(",") for log_csv in log_csv.split('\n')],
                                  columns=["UWBI", "CommonName", "MeasuredDepth", "TVD", "Azimuth", "Inclination",
                                           "SurfaceX", "SurfaceY", "HorizontalCRS", "VerticalUOM", "HorizontalUOM",
                                           "AzimuthReference"])
            df = log_Df.iloc[1:, :]
            df["UWBI"] = df["UWBI"].apply(lambda x: x.replace('"', ""))
            df["CommonName"] = df["CommonName"].astype(str).apply(lambda x: x.replace('"', ""))
            df["MeasuredDepth"] = df["MeasuredDepth"].astype(str).apply(lambda x: x.replace('"', ""))
            df["TVD"] = df["TVD"].astype(str).apply(lambda x: x.replace('"', ""))
            df["Azimuth"] = df["Azimuth"].astype(str).apply(lambda x: x.replace('"', ""))
            df["Inclination"] = df["Inclination"].astype(str).apply(lambda x: x.replace('"', ""))
            df["SurfaceX"] = df["SurfaceX"].astype(str).apply(lambda x: x.replace('"', ""))
            df["SurfaceY"] = df["SurfaceY"].astype(str).apply(lambda x: x.replace('"', ""))
            df["HorizontalCRS"] = df["HorizontalCRS"].astype(str).apply(lambda x: x.replace('"', ""))
            df["VerticalUOM"] = df["VerticalUOM"].astype(str).apply(lambda x: x.replace('"', ""))
            df["HorizontalUOM"] = df["HorizontalUOM"].astype(str).apply(lambda x: x.replace('"', ""))
            df["AzimuthReference"] = df["AzimuthReference"].astype(str).apply(lambda x: x.replace('"', ""))
            df['MeasuredDepth'] = pd.to_numeric(df['MeasuredDepth'], errors='coerce')
            df["Azimuth"] = pd.to_numeric(df['Azimuth'], errors='coerce')
            df["Inclination"] = pd.to_numeric(df['Inclination'], errors='coerce')
            md_list = df['MeasuredDepth'].to_numpy()
            azm_array = df["Azimuth"].to_numpy()
            inc_array = df["Inclination"].to_numpy()
            arr = np.dstack((md_list, inc_array, azm_array))[0]
            #     #print(arr.tolist())
            tvd_data = md_tvd(arr.tolist())
            Finaldata = tvd_data.tolist()
            #     #print(Finaldata)
            FinalData_dict = {"data": Finaldata, "meta_data": {
                "columns": ["Measured_Depth", "Inclination", "Azimuth", "TVD", "Northing", "Easting"],
                "units": ["m", "dega", "dega"]}}
            # #print(FinalData_dict)
            Final_Json = json.dumps(FinalData_dict)
            deviationdata[wellboreId] = Final_Json

    # COMMAND ----------

    if str(well_traj_DE_value) == str(1):
        # print("done")
        input_data = spark.sql(
            "select wellboreId from {}_well_registry_db.deviation_survey".format(companyName)).collect()
        # #print(input_data)
        input_data_list = []
        for input in input_data:
            input_data_list.append(input.asDict()['wellboreId'])
        for key, value in deviationdata.items():
            if int(key) in input_data_list:
                header = spark.sql(
                    "update " + companyName + "_well_registry_db.deviation_survey set deviationData='" + value + "'where wellboreId  ="
                    + str(key) + "")
            else:
                header_data = spark.sql(
                    "insert into " + companyName + "_well_registry_db.deviation_survey values(" + str(key) + " ,'" + value + "','"+str(key)+"')")

    if str(well_log_DE_value) == str(1):
        previous_data = \
        spark.sql("select wellboreId from {}_well_logs_db.well_logs_header".format(companyName)).toPandas()[
            "wellboreId"].to_list()
        wells_query_data = spark.sql(
            f"select wellId, wellName, wellboreId, wellboreName from {companyName}_well_registry_db.wellbore where wellId in ({','.join(list(wellnames.keys()))})").toPandas()
        for row in wells_query_data.iloc():
            logFileId = random.randint(0, 9999999)
            wb_log_data_info = queryWellboreLogs(headers, str(row["wellboreId"]))
            for i in wb_log_data_info:
                datasets = i["datasets"]
                if len(datasets) > 0:
                    wellboreLog_Data = queryWellboreLogData(headers, datasets[0])
                    las_df = lasio.read(wellboreLog_Data)
                    type(las_df.curves)
                    curvesCount = len(las_df.curves)
                    row_values_dict = {}
                    if str(row["wellboreId"]) in previous_data:
                        logFileIdQuery = spark.sql(
                            f"select logFileId from {companyName}_well_logs_db.well_logs_header where wellboreId = {str(row['wellboreId'])}").toPandas()[
                            "logFileId"].to_list()
                        if len(logFileIdQuery) > 0:
                            logFileId = logFileIdQuery[0]
                    for k in range(0, curvesCount):
                        curveItem = las_df.curves[k]
                        mnemonic = curveItem.mnemonic
                        unit = curveItem.unit
                        unitCategory = "unknown"
                        originalMnemonic = curveItem.original_mnemonic
                        dataSize = str(curveItem.data.shape[0])
                        basinId = basinID
                        basinName = basinName
                        wellboreId = str(row["wellboreId"])
                        wellboreName = str(row["wellboreName"])
                        wellId = str(row["wellId"])
                        wellName = str(row["wellName"])
                        logId = str(random.randint(0, 9999999))
                        fileName = f"{wellboreId}_file"
                        logFileId = str(logFileId)
                        mapped = "NO"
                        if wellboreId not in previous_data:
    #                         spark.sql(
    #                             f"update {companyName}_well_logs_db.well_logs_header set mnemonic='{mnemonic}',unit='{unit}',unitCategory='{unitCategory}',originalMnemonic='{originalMnemonic}',dataSize='{dataSize}',basinId='{basinId}',basinName='{basinName}',wellId='{wellId}',wellName='{wellName}',wellboreId='{wellboreId}',wellboreName='{wellboreName}',logId='{logId}',fileName='{fileName}',logFileId='{logFileId}',mapped='yes' where wellboreId='{wellboreId}'")
    #                     else:
                            spark.sql(
                                f"insert into {companyName}_well_logs_db.well_logs_header (mnemonic, unit, unitCategory, originalMnemonic, dataSize, basinId, basinName, wellId, wellName, wellboreId, wellboreName, logId, fileName, logFileId, mapped) values('{mnemonic}','{unit}','{unitCategory}','{originalMnemonic}','{dataSize}','{basinId}','{basinName}','{wellId}','{wellName}','{wellboreId}','{wellboreName}','{logId}','{fileName}','{logFileId}','yes')")

                    curveNames = las_df.keys()
                    las_pdf = pd.DataFrame()
                    numberOfCurves = len(curveNames)
                    for k in range(0, numberOfCurves):
                        columnName = curveNames[k]
                        las_pdf[columnName] = las_df[columnName]
                        las_curve_data_frame = spark.createDataFrame(las_pdf)
                        las_curve_data_frame = las_curve_data_frame.sort("DEPT")
                    OUTPUT_DATA_TABLE = "well_logs_data_" + str(logFileId)
                    WELL_LOG_DATA_DELTA_LAKE_PATH = Delta_Data_Path + str(logFileId)
                    las_curve_data_frame.write.format('delta').mode("overwrite").option("overwriteSchema", "true").save(
                        WELL_LOG_DATA_DELTA_LAKE_PATH)
                    spark.sql("DROP TABLE IF EXISTS {}_well_logs_db.{}".format(companyName, OUTPUT_DATA_TABLE))
                    spark.sql("CREATE TABLE {}_well_logs_db.{} USING DELTA LOCATION '{}'".format(companyName,
                                                                                                 OUTPUT_DATA_TABLE,
                                                                                                 WELL_LOG_DATA_DELTA_LAKE_PATH))