# import requests
# from pyspark.sql.functions import col
import re
import findspark
findspark.init()
findspark.find()
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql import SparkSession
from pyspark.sql.types import StructField, StructType, StringType, IntegerType, DecimalType, FloatType
spark=SparkSession.builder.master("local[1").appName("sparkByExamples.com").getOrCreate()

import segyio
# import numpy as np
# import os
# import shutil
# import pathlib
# import json
# import matplotlib.pyplot as plt
# from shutil import copyfile
# from hashlib import md5
# from base64 import b64encode
import pandas as pd



def seismic_data_processor(source_data_path,seismic_delta_lake_path, delta_lake_loc,database,segy_filepath,companyName):
    segy_header_delta_lake_path = seismic_delta_lake_path + '/segy_header/'
    segy_trace_data_delta_lake_path = seismic_delta_lake_path + '/segy_trace_data/'
    with segyio.open(segy_filepath, ignore_geometry=True) as f:
        f.mmap()
        print("Total Number of Traces:  ", f.tracecount)
        # Get all header keys:
        header_keys = segyio.tracefield.keys
        # Initialize df with trace id as index and headers as columns
        trace_headers = pd.DataFrame(index=range(1, f.tracecount + 1),
                                     columns=header_keys.keys())
        # Fill dataframe with all trace headers values
        for k, v in header_keys.items():
            trace_headers[k] = f.attributes(v)[:]
    seismic_header_df = spark.createDataFrame(trace_headers)
    seismic_header_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(
        segy_header_delta_lake_path)

    spark.sql("CREATE DATABASE IF NOT EXISTS {}".format(database))

    spark.sql("DROP TABLE IF EXISTS {}.{}".format(database, "seismic_header"))
    spark.sql(
        "CREATE TABLE {}.{} USING DELTA LOCATION '{}'".format(database, "seismic_header", segy_header_delta_lake_path))

    # read header data from delta
    seismic_header_data = spark.sql("select * from {}_seismic_volve_db.seismic_header".format(companyName))

    x = seismic_header_data.select('TRACE_SEQUENCE_FILE').collect()

    trace_indices = [str(num).replace('Row(TRACE_SEQUENCE_FILE=', '').replace(')', '') for num in x]
    trace_indices.sort()

    f = segyio.open(segy_filepath, ignore_geometry=True)
    f.mmap()
    trace_count = int(len(trace_indices))
    print("Trace Count: ", trace_count)
    chunk_size = 20000
    no_of_chunk_intervals = int(trace_count / chunk_size)
    k_array = []
    #   no_of_chunk_intervals = 2
    for index in range(0, no_of_chunk_intervals):
        i = (index + 1) * chunk_size
        k_array.append(i)
    print(k_array)

    # first clear the output table # assumption is we are reprocessing the output
    # dbutils.fs.mkdirs(segy_trace_data_delta_lake_path)
    # dbutils.fs.rm(segy_trace_data_delta_lake_path, recurse=True)

    trace_matrix = []
    #   trace_count = 2
    for i in range(0, trace_count):
        #     print("------------------------")
        #     if i > 20000:
        #       break
        temp = f.trace[i]
        #     print(temp)
        listToStr = [str(element) for element in temp]
        # trace id starts with 1
        listToStr.append(int(i))
        #     print(listToStr)
        trace_matrix.append(listToStr)
        if i in k_array:
            print("Processed ", i, " Traces")
            #       print("Adding Chunk to Delta")
            df = pd.DataFrame.from_records(trace_matrix)
            #       print("------------------------")
            #       print(df.columns)
            #       print("------------------------")
            chunk_trace_data_df = spark.createDataFrame(df)
            lastColumn = str(len(chunk_trace_data_df.columns) - 1)
            chunk_trace_data_df = chunk_trace_data_df.withColumnRenamed(lastColumn, "trace_id")
            chunk_trace_data_df = chunk_trace_data_df.withColumn("trace_id",
                                                                 chunk_trace_data_df["trace_id"].cast(IntegerType()))

            if i == k_array[0]:
                print("Writing the first chunk of data to Deltalake with Schema")
                lastColumn = str(len(chunk_trace_data_df.columns) - 1)
                #         print("------------------------")
                #         print(chunk_trace_data_df.columns)
                #         print("------------------------")
                #         ENABLE WRITE AFTER FINALIZING THE PATH
                chunk_trace_data_df.write.format("delta").mode("append").option("overwriteSchema", "true").save(
                    segy_trace_data_delta_lake_path)
            #       # rename the last column as trace_id
            #        chunk_trace_data_df = chunk_trace_data_df.withColumnRenamed()
            #       # write to delta
            else:
                print("Appending Chunk to Deltalake without Schema")
                #         ENABLE WRITE AFTER FINALIZING THE PATH
                chunk_trace_data_df.write.format("delta").mode("append").save(segy_trace_data_delta_lake_path)
            trace_matrix = []
            print("Resetting chunk trace_array")
        if i > k_array[len(k_array) - 1] and i == (trace_count - 1):
            # add the last chunk
            print("Writing the last chunk of traces to Delta")
            df = pd.DataFrame.from_records(trace_matrix)
            chunk_trace_data_df = spark.createDataFrame(df)
            lastColumn = str(len(chunk_trace_data_df.columns) - 1)
            chunk_trace_data_df = chunk_trace_data_df.withColumnRenamed(lastColumn, "trace_id")
            chunk_trace_data_df = chunk_trace_data_df.withColumn("trace_id",
                                                                 chunk_trace_data_df["trace_id"].cast(IntegerType()))
            # write to delta
            chunk_trace_data_df.write.format("delta").mode("append").option("overwriteSchema", "true").save(
                segy_trace_data_delta_lake_path)
            print("Appending Last Chunk to Delta with Schema")
            #         ENABLE WRITE AFTER FINALIZING THE PATH
            chunk_trace_data_df.write.format("delta").mode("append").option("overwriteSchema", "true").save(
                segy_trace_data_delta_lake_path)

            spark.sql("DROP TABLE IF EXISTS {}.{}".format(database, "seismic_trace_data"))
            spark.sql("CREATE TABLE {}.{} USING DELTA LOCATION '{}'".format(database, "seismic_trace_data",
                                                                            segy_trace_data_delta_lake_path))