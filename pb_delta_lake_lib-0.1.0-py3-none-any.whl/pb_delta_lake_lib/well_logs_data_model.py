# import requests
# from pyspark.sql.functions import col
import re
import findspark
findspark.init()
findspark.find()
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql import SparkSession
from pyspark.sql.types import StructField, StructType, StringType, IntegerType, DecimalType, FloatType
from pyspark.sql.functions import lit, col
spark=SparkSession.builder.master("local[1").appName("sparkByExamples.com").getOrCreate()

import lasio
from array import array
import pandas as pd
import uuid
import random



def well_logs_data_processor(CURRENT_LAS_FILE_PATH,Las_filename, WELL_LOG_HEADER_DELTA_LAKE_PATH,WELL_LOG_DATA_DELTA_LAKE_PATH,DATABASE_NAME):
    Log_file_ID = random.randint(0, 9999999)
    WELL_LOG_DATA_DELTA_LAKE_PATH=WELL_LOG_DATA_DELTA_LAKE_PATH+ str(Log_file_ID)
    OUTPUT_HEADER_TABLE = "well_logs_header"
    OUTPUT_DATA_TABLE = "well_logs_data_" + str(Log_file_ID)
    TABLE_NAME_PREFIX = "log_data_"
    las_df = lasio.read(CURRENT_LAS_FILE_PATH)
    curveHeaderColumns = ['mnemonic', 'unit', 'unitCategory', 'originalMnemonic', 'dataSize', 'basinId',
                          'basinName', 'wellId', 'wellName', 'wellboreId', 'wellboreName', 'logId', 'fileName',
                          'logFileId', 'mapped']
    # curveHeaderColumns = []

    header_pdf = pd.DataFrame(columns=curveHeaderColumns)
    type(las_df.curves)
    curvesCount = len(las_df.curves)
    row_values_dict = {}
    print(curvesCount)
    for k in range(0, curvesCount):
        curveItem = las_df.curves[k]
        row_values_dict['mnemonic'] = curveItem.mnemonic
        row_values_dict['unit'] = curveItem.unit
        row_values_dict['unitCategory'] = "unknown"
        row_values_dict['originalMnemonic'] = curveItem.original_mnemonic
        row_values_dict['dataSize'] = str(curveItem.data.shape[0])
        row_values_dict['basinId'] = "unknown"
        row_values_dict['basinName'] = "unknown"
        row_values_dict['wellId'] = "unknown"
        row_values_dict['wellName'] = "unknown"
        row_values_dict['wellboreId'] = "unknown"
        row_values_dict['wellboreName'] = "unknown"
        row_values_dict['logId'] = random.randint(0, 9999999)
        row_values_dict['fileName'] = Las_filename
        row_values_dict['logFileId'] = str(Log_file_ID)
        row_values_dict['mapped'] = "NO"

        header_pdf = header_pdf.append(row_values_dict, ignore_index=True)

    las_curve_header_frame = spark.createDataFrame(header_pdf)

    # WRITE HEADER TO DELTA
    las_curve_header_frame.write.format('delta').option("overwriteSchema", "true").mode("append").save(
        WELL_LOG_HEADER_DELTA_LAKE_PATH)
    spark.sql("create schema IF NOT EXISTS {}".format(DATABASE_NAME))
    spark.sql("CREATE TABLE IF NOT EXISTS {}.{} USING DELTA LOCATION '{}'".format(DATABASE_NAME, OUTPUT_HEADER_TABLE,
                                                                                  WELL_LOG_HEADER_DELTA_LAKE_PATH))
    curveNames = las_df.keys()
    las_pdf = pd.DataFrame()
    numberOfCurves = len(curveNames)
    for k in range(0, numberOfCurves):
        columnName = curveNames[k]
        #   print(columnName)
        las_pdf[columnName] = las_df[columnName]

    # print(las_pdf)
    # plt.plot('DEPTH','COMPOSITE_DENSITY3',data=las_pdf)
    # plt.show()
    # convert to spark data frame
    las_curve_data_frame = spark.createDataFrame(las_pdf)
    las_curve_data_frame2 = las_curve_data_frame
    las_curve_data_frame = las_curve_data_frame2.sort("DEPTH")
    # WRITE CURVE DATA TO DELTA
    las_curve_data_frame.write.format('delta').mode("overwrite").option("overwriteSchema", "true").save(WELL_LOG_DATA_DELTA_LAKE_PATH)
    spark.sql("CREATE TABLE {}.{} USING DELTA LOCATION '{}'".format(DATABASE_NAME, OUTPUT_DATA_TABLE,WELL_LOG_DATA_DELTA_LAKE_PATH))

